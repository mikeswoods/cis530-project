=== Team W^2: Stuart Wagner and Michael Woods ===

* All source code is included in the zip file named "proj_source.zip"

After unzipping,tThe program can be run by entering the project's code/
directory, and typing the following:

  ./run.py <name-of-model>, e.g. ./run.py linear, ./run.py ensemble, etc.

All available models are listed as Python moddules in the code/project/models
directory.

The program has a number of options that are displayed by supplying the --help
flag:

usage: run.py [-h] [--submit] [--iters ITERATIONS] [-T TEST_SIZE]
              [-F TEST_FEATURE] [--recache]
              model

positional arguments:
  model               The model to run

optional arguments:
  -h, --help          show this help message and exit
  --submit            Generate a submission
  --iters ITERATIONS  Run N test iterations, averaging the results
  -T TEST_SIZE        xval test size (default = 0.1
  -F TEST_FEATURE     Call the feature's test() function
  --recache           Regenerate cache data

* The report is available in the report.pdf file. It was typeset using LaTeX

Thanks!
